import xbmcaddon

MainBase = 'http://bit.ly/2hiwuCq'
addon = xbmcaddon.Addon('plugin.audio.ArminFM')